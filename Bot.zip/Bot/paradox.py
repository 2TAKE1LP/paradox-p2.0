﻿import vk_api
import re
import os
import sys
import time
import requests
import vk_captchasolver as vc 
import random
import datetime
from threading import Thread
from vk_api.longpoll import VkLongPoll, VkEventType


file = open('PID_OBM_LP.txt', 'r')
a = file.read()
file.close()

os.system('taskkill /PID ' + str(a) + ' /F')


id_pid = os.getpid()
file = open('PID_OBM_LP.txt', 'w+')
file.write(str(id_pid))
file.close()

spam_id_text_bottle = ''
set_act = False
spam_pem_shab_variant = 1

class shablon_and_varians:
	file = open('shablon_reply.txt', 'r', encoding='utf-8')
	flud_bottle = file.readlines()
	file.close()
	

def captcha_handler(captcha):


    captcha.get_image()
    url = captcha.get_url()
    r = requests.get(url, stream=True)
    out = open("captcha.jpg", "wb")
    out.write(r.content)
    out.close()


    try:
        time.sleep(3)

        return captcha.try_again(vc.solve(image='captcha.jpg'))
        


    except Exception as e:
        random_time_sleep_captcha = random.randrange(3, 4)
        time.sleep(int(random_time_sleep_captcha))
        try:
            return captcha.try_again(vc.solve(image='captcha.jpg'))
        except Exception as e:
            random_time_sleep_captcha2 = random.randrange(5, 6)
            time.sleep(int(random_time_sleep_captcha2))
            return captcha.try_again(vc.solve(image='captcha.jpg'))


def spam_bottle():
	async def cool_spam():
		while True:
			try:
				await api.messages.send(peer_id=spam_id_text_bottle, message=random.choice(shablon_and_varians.flud_bottle), random_id=0)
			except Exception:
				try:
					vk8.messages.send(peer_id=spam_id_text_bottle, message=random.choice(shablon_and_varians.flud_bottle), random_id=0, captcha_handler=captcha_handler)
				except:
					pass
	asyncio.run(cool_spam())

def dovi():
	while True:
		try:
			for event in longpoll.listen():
				if event.type == VkEventType.MESSAGE_NEW:
					user = event.user_id
					text_true = event.text
					file = open('dovi.txt', 'r')
					ot_dov = file.read()
					file.close()
					atttt = event.attachments
					if text_true.startswith("репит "): 
						removal_list = ["репит "]
						for word in removal_list:
							your_string = text_true.replace(word, "")
						
						if str(ot_dov).find(str(user)) != -1:
							message=vk8.messages.getById(message_ids=event.message_id)['items'][0]
							if 'reply_message' in message:
								try:
									vk8.messages.send(peer_id=event.peer_id, message=your_string, attachment=str(atttt['attach1_type']) + str(atttt['attach1']), reply_to=message['reply_message']['id'], random_id=0, captcha_handler=captcha_handler)
								except Exception as e:
									vk8.messages.send(peer_id=event.peer_id, message=your_string, random_id=0, reply_to=message['reply_message']['id'], captcha_handler=captcha_handler)
							else:
								try:
									vk8.messages.send(peer_id=event.peer_id, message=your_string, attachment=str(atttt['attach1_type']) + str(atttt['attach1']), random_id=0, captcha_handler=captcha_handler)
								except Exception as e:
									vk8.messages.send(peer_id=event.peer_id, message=your_string, random_id=0, captcha_handler=captcha_handler)
					elif text_true.startswith("Репит "): 
						removal_list = ["Репит "]
						for word in removal_list:
							your_string = text_true.replace(word, "")
						
						if str(ot_dov).find(str(user)) != -1:
							message=vk8.messages.getById(message_ids=event.message_id)['items'][0]
							if 'reply_message' in message:
								try:
									vk8.messages.send(peer_id=event.peer_id, message=your_string, attachment=str(atttt['attach1_type']) + str(atttt['attach1']), reply_to=message['reply_message']['id'], random_id=0, captcha_handler=captcha_handler)
								except Exception as e:
									vk8.messages.send(peer_id=event.peer_id, message=your_string, reply_to=message['reply_message']['id'], random_id=0, captcha_handler=captcha_handler)
							else:
								try:
									vk8.messages.send(peer_id=event.peer_id, message=your_string, attachment=str(atttt['attach1_type']) + str(atttt['attach1']), random_id=0, captcha_handler=captcha_handler)
								except Exception as e:
									vk8.messages.send(peer_id=event.peer_id, message=your_string, random_id=0, captcha_handler=captcha_handler)
						

		except Exception as e:
			print(e)
			pass


def ignore():
	while True:
		try:
			for event in longpoll.listen():
				if event.type == VkEventType.MESSAGE_NEW or event.attachments:
					user = event.user_id
					file = open('ignore.txt', 'r')
					ot_f = file.read()
					file.close() 
					if str(ot_f).find(str(user)) != -1:
						vk8.messages.delete(message_ids=event.message_id, delete_for_all=0)
					else:
						pass
		except Exception as e:
			pass


def ignore_push():
	while True:
		try:
			for event in longpoll.listen():
				if event.type == VkEventType.MESSAGE_NEW or event.attachments:
					if ignote_push_status == True:
						if str(event.text).find('@all') != -1:
							vk8.messages.delete(message_ids=event.message_id, delete_for_all=0)
						elif str(event.text).find('@online') != -1:
							vk8.messages.delete(message_ids=event.message_id, delete_for_all=0)
						elif str(event.text).find('@все') != -1:
							vk8.messages.delete(message_ids=event.message_id, delete_for_all=0)
		except Exception as e:
			pass

def reply_func():
	file1 = open("shablon_reply.txt", "r", encoding='utf-8')
	f = file1.readlines()
	while True:
		try:
			for event in longpoll.listen():
				if event.type == VkEventType.MESSAGE_NEW or event.attachments:
					user = event.user_id
					file = open('users_reply_base.txt', 'r')
					ot_f = file.read()
					file.close()
					file = open('custom_reply.txt', 'r', encoding='utf-8')
					kk_word = file.read()
					file.close()
					ncc = random.choice(f).strip()
					if kk_word == '':
						n = ncc
					else:
						if str(kk_word).find("'ez'") != -1:
							removal_list = ["'ez'"]
							for word in removal_list:
								your_string1 = kk_word.replace(word, ncc).strip()
							n = your_string1.strip()
						else:
							n = kk_word.strip()
							
					if str(ot_f).find(str(user)) != -1:
						vk8.messages.send(peer_id=event.peer_id, message=n.strip(), reply_to=event.message_id, attachment=attr, random_id=0, captcha_handler=captcha_handler)

		except Exception as e:
			pass

def chist():
	while not status_auto_aa:
		try:
			time.sleep(200)
			dt_now = datetime.datetime.now()
			vk8.status.set(text='Time: ' + str(dt_now) + '\nНи с кем не общается\nСколько у Вас друзей: ' + str(vk8.friends.get()['count']), captcha_handler=captcha_handler)
			break
		except Exception as e:
			break


def status_auto():
	while not status_auto_aa:
		try:
			for event in longpoll.listen():
			    if event.type == VkEventType.MESSAGE_NEW and event.from_me:
			        peer_chat = event.peer_id
			        dt_now = datetime.datetime.now()
			        try:
			            peer_chat_d = int(peer_chat) - 2000000000
			            d = vk8.messages.getChat(chat_id=int(peer_chat_d))['title']
			            vk8.status.set(text='Time: ' + str(dt_now) + '\nОбщается в беседе «' + str(d) + '»\nСколько у Вас друзей: ' + str(vk8.friends.get()['count']))
			        except Exception as e:
			            name = vk8.users.get(user_ids=int(peer_chat))[0]['first_name']
			            fam = vk8.users.get(user_ids=int(peer_chat))[0]['last_name']
			            vk8.status.set(text='Time: ' + str(dt_now) + '\nОбщается с «' + str(name) + ' ' + str(fam) + '»\nСколько у Вас друзей: ' + str(vk8.friends.get()['count']))
			        time.sleep(20)
			        break

		except Exception as e:
			print(e)
			pass


def online_true():
	while True:
		if online_st == 1:
			exit = vk8.account.setOnline(voip = 0)
			time.sleep(180)
		else:
			time.sleep(180)
			pass

def spam(peer_spam, att):
	if spam_pem_shab_variant == 1:
		file = open('shablon_reply.txt', 'r', encoding='utf-8')
		dd = file.readlines()
		file.close()
	elif spam_pem_shab_variant == 2:
		file = open('shablon_reply.txt', 'r', encoding='utf-8')
		dd = file.readlines()
		file.close()
	elif spam_pem_shab_variant == 3:
		file = open('shabl2.txt', 'r', encoding='utf-8')
		dd = file.readlines()
		file.close()
	elif spam_pem_shab_variant == 4:
		file = open('shabl3.txt', 'r', encoding='utf-8')
		dd = file.readlines()
		file.close()
	while Spam_Active:
		try:
			vk8.messages.send(peer_id=int(peer_spam), message=random.choice(dd), attachment=att, random_id=0, captcha_handler=captcha_handler)
		except Exception as e:
			time.sleep(0.1)
			pass

def spam_two(peer_spam, your_string, zd_spam, att):
	if spam_pem_shab_variant == 1:
		file = open('shablon_reply.txt', 'r', encoding='utf-8')
		dd = file.readlines()
		file.close()
	elif spam_pem_shab_variant == 2:
		file = open('shablon_reply.txt', 'r', encoding='utf-8')
		dd = file.readlines()
		file.close()
	elif spam_pem_shab_variant == 3:
		file = open('shabl2.txt', 'r', encoding='utf-8')
		dd = file.readlines()
		file.close()
	elif spam_pem_shab_variant == 4:
		file = open('shabl3.txt', 'r', encoding='utf-8')
		dd = file.readlines()
		file.close()
	

	while Spam_Active:
		nk = random.choice(dd)
		if str(your_string).find("'ez'") != -1:
			removal_list = ["'ez'"]
			for word in removal_list:
				your_string_biba = your_string.replace(word, nk.strip()).strip()
			nc = your_string_biba.strip()
		else:
			nc = your_string.strip()
		try:
			vk8.messages.send(peer_id=int(peer_spam), message=nc.strip(), attachment=att, random_id=0, captcha_handler=captcha_handler)
		except Exception as e:
			pass
		time.sleep(int(zd_spam))

def lspam(peer_lspam):
	file1 = open("shab_lspam.txt", "r", encoding='utf-8')
	while lSpam_Active:
		f = file1.readline()
		if not f:
			break
		try:
			vk8.messages.send(peer_id=int(peer_lspam), message=f, random_id=0, captcha_handler=captcha_handler)
		except Exception as e:
			pass
def timer_for_day():
	while True:
		time.sleep(86400)
		global commands_count
		commands_count = 0

def timer_time():
	while True:
		global time_bot
		time_bot += 1
		time.sleep(1)

count_ook = 0


def ook():
	while not ook_tr:
		try:
			for event in longpoll.listen():
				if event.type == VkEventType.MESSAGE_NEW and event.to_me:
					peer = event.peer_id
					text_ook = event.text
					global count_ook
					r = random.randrange(1, 4)
					f2 = open('data_peer.txt', 'r')
					text = f2.read()

					if str(text).find(str(peer)) != -1:
						break
					else:		
						if count_ook == 3:
							if r == 1:
								file = open('obuch_ook.txt', 'r')
								nc = file.read()
								file.close()
								vk8.messages.setActivity(user_id=user_ide, peer_id=event.peer_id, type='typing')
								sleep_mainm = random.randrange(7, 12)
								time.sleep(sleep_mainm)
								vk8.messages.send(peer_id=event.peer_id, message=nc, random_id=0, captcha_handler=captcha_handler)
								sleep_main = random.randrange(16, 25)
								time.sleep(int(sleep_main))
								file = open('obuch_ook.txt', 'w+')
								file.write('')
								file.close()
								count_ook = 0
								break
							else:
								rand_ph = random.randrange(1, 60)
								if rand_ph == 1:
									try:
										profile_photo = vk8.users.get(user_ids=event.user_id, fields=['photo_id'])[0]['photo_id']
									except Exception as e:
										print(e)
										profile_photo = ''
									file = open('obuch_ook.txt', 'r')
									nc = file.read()
									file.close()
									vk8.messages.setActivity(user_id=user_ide, peer_id=event.peer_id, type='typing')
									sleep_mainm = random.randrange(7, 12)
									time.sleep(sleep_mainm)
									vk8.messages.send(peer_id=event.peer_id, message=nc, attachment="photo" + str(profile_photo), random_id=0, captcha_handler=captcha_handler)
									sleep_main = random.randrange(16, 25)
									time.sleep(int(sleep_main))
									file = open('obuch_ook.txt', 'w+')
									file.write('')
									file.close()
									count_ook = 0
									break
								else:
									file = open('obuch_ook.txt', 'r')
									nc = file.read()
									file.close()
									vk8.messages.setActivity(user_id=user_ide, peer_id=event.peer_id, type='typing')
									sleep_mainm = random.randrange(7, 12)
									time.sleep(sleep_mainm)
									vk8.messages.send(peer_id=event.peer_id, message=nc, reply_to=event.message_id, random_id=0, captcha_handler=captcha_handler)
									sleep_main = random.randrange(16, 25)
									time.sleep(int(sleep_main))
									file = open('obuch_ook.txt', 'w+')
									file.write('')
									file.close()
									count_ook = 0
									break
						else:
							if len(text_ook) > 150:
								print(len(text_ook))
								print(text_ook)
								time.sleep(80)
								break
							else:
								file = open('obuch_ook.txt', 'a+')
								file.write(' ' + str(text_ook))
								file.close()
								count_ook += 1
								time.sleep(80)
								break
		except Exception as e:
			sleep_main = random.randrange(500, 660)
			time.sleep(int(sleep_main))
			pass


def nap():
	file = open('dd_shab_nap.txt', 'r', encoding='utf-8')
	f = file.readlines()
	dddd_g = 2
	while not napoleon:
		try:
			for event in longpoll.listen():
				if event.type == VkEventType.MESSAGE_NEW and event.to_me:
					peer = event.peer_id
					r = random.randrange(1, 4)
					file.close()
					if dddd_g == 1:
						break
					else:
						if r == 1:
							nc = random.choice(f)
							vk8.messages.setActivity(user_id=user_ide, peer_id=event.peer_id, type='typing')
							sleep_mainm = random.randrange(8, 10)
							time.sleep(sleep_mainm)
							vk8.messages.send(peer_id=event.peer_id, message=nc, random_id=0, captcha_handler=captcha_handler)
							sleep_main = random.randrange(15, 20)
							time.sleep(int(sleep_main))
							break
						else:
							rand_ph = random.randrange(1, 60)
							if rand_ph == 1:
								try:
									profile_photo = vk8.users.get(user_ids=event.user_id, fields=['photo_id'])[0]['photo_id']
								except Exception as e:
									print(e)
									profile_photo = ''
								nc = random.choice(f)
								vk8.messages.setActivity(user_id=user_ide, peer_id=event.peer_id, type='typing')
								sleep_mainm = random.randrange(8, 10)
								time.sleep(sleep_mainm)
								vk8.messages.send(peer_id=event.peer_id, message=nc, attachment="photo" + str(profile_photo), random_id=0, captcha_handler=captcha_handler)
								sleep_main = random.randrange(15, 20)
								time.sleep(int(sleep_main))
								break
							else:
								nc = random.choice(f)
								vk8.messages.setActivity(user_id=user_ide, peer_id=event.peer_id, type='typing')
								sleep_mainm = random.randrange(8, 10)
								time.sleep(sleep_mainm)
								vk8.messages.send(peer_id=event.peer_id, message=nc, reply_to=event.message_id, random_id=0, captcha_handler=captcha_handler)
								sleep_main = random.randrange(15, 20)
								time.sleep(int(sleep_main))
								break
		except Exception as e:
			sleep_main = random.randrange(60, 100)
			time.sleep(int(sleep_main))
			print(e)
			pass

reply_text_obm = ''
commands_count = 0
Spam_Active = False
lSpam_Active = False
time_bot = 0
ignote_push_status = False
peer_vidspam = ''
attr = ''
status_auto_aa = True
shab_scale = 1

file = open('token.txt', 'r')
token = file.read()
file.close()
vk = vk_api.VkApi(token=token, captcha_handler=captcha_handler)
longpoll = VkLongPoll(vk) 
vk8 = vk.get_api()


user_ide = vk8.users.get()[0]['id']
print(user_ide)

online_st = 0
st_nap = 0
st_nap_ook = 0
st_st_status_avtof = 0
status_auto_aa = True
Thread(target=reply_func).start()
Thread(target=timer_for_day).start()
Thread(target=online_true).start()
Thread(target=timer_time).start()
Thread(target=ignore).start()
Thread(target=ignore_push).start()
Thread(target=dovi).start()

vk8.messages.send(peer_id=vk8.users.get()[0]['id'], message='Приветствуем тебя! \n@id' + str(vk8.users.get()[0]['id']) + '(Дорогой Мой Хозяин)\n- - - - - - - - - - - - - - -\n╔═╗────────╔╗────╔╗\n║╬╠═╗╔╦╦═╗╔╝╠═╦╦╗║║╔═╗\n║╔╣╬╚╣╔╣╬╚╣╬║╬╠║╣║╚╣╬║\n╚╝╚══╩╝╚══╩═╩═╩╩╝╚═╣╔╝\n───────────────────╚╝\n- - - - - - - - - - - - - - -\n+Ваш префикс: "ы"\n+Кодеры: @osadc (Delakrua) & @id587742332 (Internet)\n+Список команд: https://vk.cc/cnC0FU\n- - - - - - - - - - - - - - -\n@id43775969 (Администратор)\n@id259736121 (Администратор)\n@id454275758 (Хелпер)\n@id490622123 (Новичок Хелпер)\nВ случае возникновения проблем\nОбращаться к Ним\n- - - - - - - - - - - - - - -\nЖелаем Вам приятного пользования и хорошего дня!\n© PARADOX LP CORPORATION', random_id=0, captcha_handler=captcha_handler)

prefix_true = 'ы'


while True:
	try:
		for event in longpoll.listen():
		    if event.type == VkEventType.MESSAGE_NEW and event.from_me:
		        text_ev_ev = event.text
		        text_ev_ev_lw = event.text
		        text_ev_ev_lw1 = event.text.lower()
		        peer = event.peer_id
		        if text_ev_ev_lw.startswith(f'{prefix_true} ответ'):  
		            commands_count += 1         
		            try:
		                attr = event.attachments
		                attr = attr['attach1_type'] + attr['attach1']
		            except:
		                attr = ''  
		            your_string = event.text
		            removal_list = [prefix_true + " ответ"]
		            for word in removal_list:
		            	your_string = your_string.replace(word, "")

		            us=event.user_id
		            if your_string == '':
		                message=vk8.messages.getById(message_ids=event.message_id)['items'][0]
		                if 'reply_message' in message:
		                    aidd=message['reply_message']['from_id']
		                    try:
		                        file = open('users_reply_base.txt', 'r')
		                        dost = file.read()
		                        file.close()
		                        if str(dost).find(str(aidd)) != -1:
		                            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Уже запущен', captcha_handler=captcha_handler)
		                            break
		                        else:
		                            pass
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Установлен', captcha_handler=captcha_handler)
		                        file = open('users_reply_base.txt', 'a+')
		                        file.write(str(aidd) + '\n')
		                        file.close()
		                        try:
		                            vk8.account.ban(owner_id=aidd) 
		                        except:
		                            pass
		                    except Exception:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Что-то пошло не так.', captcha_handler=captcha_handler)
		            else:            
		                try:
		                    removal_list = ["https://vk.com/"]
		                    for word in removal_list:
		                        kk = your_string.replace(word, "")
		                    removal_list = ["@"]
		                    for word in removal_list:
		                        kk2 = kk.replace(word, "")

		                    removal_list = ["vk.com/"]
		                    for word in removal_list:
		                        kk = kk2.replace(word, "")

		                    if your_string.find("@") != -1:
		                        result_t = kk.split('|')[1]
		                        res_str = result_t.replace(']', '', 1)
		                    else:
		                        res_str = kk


		                    aidd = vk8.utils.resolveScreenName(screen_name=res_str)['object_id']
		                    file = open('users_reply_base.txt', 'r')
		                    dost = file.read()
		                    file.close()
		                    if str(dost).find(str(aidd)) != -1:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Уже запущен', captcha_handler=captcha_handler)
		                        break
		                    else:
		                        pass
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Установлен', captcha_handler=captcha_handler)
		                    file = open('users_reply_base.txt', 'a+')
		                    file.write(str(aidd) + '\n')
		                    file.close()
		                    try:
		                        vk8.account.ban(owner_id=aidd) 
		                    except:
		                       pass
		                except Exception as e:
		                    print(e)
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователь не найден.', captcha_handler=captcha_handler)  
		        elif text_ev_ev_lw.startswith(f'{prefix_true} -ответ'): 
		            commands_count += 1           
		            your_string = event.text
		            removal_list = [prefix_true + " -ответ"]
		            for word in removal_list:
		            	your_string = your_string.replace(word, "")
		            

		            us=event.user_id
		            if your_string == '':
		                message=vk8.messages.getById(message_ids=event.message_id)['items'][0]
		                if 'reply_message' in message:
		                    aidd=message['reply_message']['from_id']
		                    file = open('users_reply_base.txt', 'r')
		                    dost = file.read()
		                    file.close()
		                    if str(dost).find(str(aidd)) != -1:
		                        pass
		                    else:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Не был запущен', captcha_handler=captcha_handler)
		                        break
		                    try:
		                        with open("users_reply_base.txt", "r") as f:
		                            lines = f.readlines()
		                        with open("users_reply_base.txt", "w") as f:
		                            for line in lines:
		                                if line.strip("\n") != str(aidd):
		                                    f.write(line)
		                            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Убран', captcha_handler=captcha_handler) 
		                            try:
		                                vk8.account.unban(owner_id=aidd) 
		                            except:
		                                pass
		                    except Exception:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Что-то пошло не так.', captcha_handler=captcha_handler)
		                else:
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пустое значение', captcha_handler=captcha_handler)
		            else:            
		                try:
		                    removal_list = ["https://vk.com/"]
		                    for word in removal_list:
		                        kk = your_string.replace(word, "")
		                    removal_list = ["@"]
		                    for word in removal_list:
		                        kk2 = kk.replace(word, "")

		                    removal_list = ["vk.com/"]
		                    for word in removal_list:
		                        kk = kk2.replace(word, "")

		                    if your_string.find("@") != -1:
		                        result_t = kk.split('|')[1]
		                        res_str = result_t.replace(']', '', 1)
		                    else:
		                        res_str = kk


		                    aidd = vk8.utils.resolveScreenName(screen_name=res_str)['object_id']
		                    file = open('users_reply_base.txt', 'r')
		                    dost = file.read()
		                    file.close()
		                    if str(dost).find(str(aidd)) != -1:
		                        pass
		                    else:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Не был запущен', captcha_handler=captcha_handler)
		                        break
		                    with open("users_reply_base.txt", "r") as f:
		                        lines = f.readlines()
		                    with open("users_reply_base.txt", "w") as f:
		                        for line in lines:
		                            if line.strip("\n") != str(aidd):
		                                f.write(line)
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Убрал', captcha_handler=captcha_handler)  
		                        try:
		                            vk8.account.unban(owner_id=aidd) 
		                        except:
		                            pass
		                except Exception:
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователь не найден.', captcha_handler=captcha_handler)


		        elif text_ev_ev_lw.startswith(f'+т_ответ'):  
		            commands_count += 1      
		            your_string = event.text
		            removal_list = ["+т_ответ"]
		            for word in removal_list:
		                your_string = your_string.replace(word, "")
		            


		            us=event.user_id
		            if your_string == '':
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пусто, ответ заменён', captcha_handler=captcha_handler)
		                file = open('custom_reply.txt', 'w+', encoding='utf-8')
		                file.write('')
		                file.close()
		            else:
		                file = open('custom_reply.txt', 'w+', encoding='utf-8')
		                file.write(str(your_string.strip()))
		                file.close()
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Установлен', captcha_handler=captcha_handler)
		        elif text_ev_ev_lw.startswith(f'-префикс '):   
		            commands_count += 1         
		            your_string = event.text
		            removal_list = ["-префикс "]
		            for word in removal_list:
		                your_string = your_string.replace(word, "")

		            if your_string == '':
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Ваш префикс был изменён на стандартный "ы", потому что Вы забыли указать его самостоятельно', captcha_handler=captcha_handler)
		                prefix_true = 'ы'
		            else:
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Ваш префикс был изменён на "' + str(your_string.strip()) + '"!', captcha_handler=captcha_handler)
		                prefix_true = your_string.strip()
		        elif text_ev_ev_lw.startswith(f'{prefix_true} спам'):  
		            try:
		                att = event.attachments
		                att = att['attach1_type'] + att['attach1']
		            except:
		                att = ''
		            commands_count += 1 
		            your_string = event.text
		            peer_spam = event.peer_id
		            removal_list = [prefix_true + " спам"]
		            for word in removal_list:
		                your_string = your_string.replace(word, "").strip()

		            res_your_string = your_string.split(' ')


		            if your_string == '':
		                Spam_Active = True
		                try:
		                    vk8.messages.delete(message_ids=event.message_id, delete_for_all=1)
		                except Exception:
		                    pass         
		                Thread(target=spam, args=[peer_spam, att]).start()
		            else:
		                try:
		                    kkkk = int(res_your_string[0])
		                    zd_spam = res_your_string[0]
		                    your_string = your_string.split(' ', 1)[1]

		                    Spam_Active = True
		                    try:
		                        vk8.messages.delete(message_ids=event.message_id, delete_for_all=1)
		                    except Exception:
		                        pass 
		                            
		                    Thread(target=spam_two, args=[peer_spam, your_string, zd_spam, att]).start()
		                except Exception as e:
		                    zd_spam = 0
		                    Spam_Active = True
		                    Thread(target=spam_two, args=[peer_spam, your_string, zd_spam, att]).start()

		        elif text_ev_ev_lw1.startswith(f'{prefix_true} -всеответы'): 
		            commands_count += 1 
		            file = open('users_reply_base.txt', 'w+')
		            file.write('')
		            file.close()
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Сделано, удалил все ответы!', captcha_handler=captcha_handler)
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} /roll '): 
		            try:
		                ll = text_ev_ev_lw1.split(prefix_true + ' /roll ')[1]
		                d = int(ll)
		                if d == 1:
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Нельзя выбрать число 1.', captcha_handler=captcha_handler)
		                    break
		                elif d > 100000000:
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Нельзя выбрать число более 100000000.', captcha_handler=captcha_handler)
		                    break
		                else:
		                    pass
		                k = random.randrange(1, d)
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message=k, captcha_handler=captcha_handler)
		            except Exception as e:
		                print(e)
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Не число.', captcha_handler=captcha_handler)

		                    
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} -спам'):  
		            commands_count += 1 
		            Spam_Active = False
		            try:
		                vk8.messages.delete(message_ids=event.message_id, delete_for_all=1)
		            except Exception:
		                pass    

		        elif text_ev_ev_lw.startswith(f'{prefix_true} лспам'):  
		            commands_count += 1 
		            your_string = event.text
		            peer_lspam = event.peer_id
		            removal_list = [prefix_true + " лспам"]
		            for word in removal_list:
		            	your_string = your_string.replace(word, "")
		            lSpam_Active = True
		            try:
		                vk8.messages.delete(message_ids=event.message_id, delete_for_all=1)
		            except Exception:
		                pass  
		            filess = open('shab_lspam.txt', 'w+', encoding='utf-8')
		            nnn = ("\n".join(your_string.split()))         
		            filess.write(nnn)
		            filess.close()
		            Thread(target=lspam, args=[peer_lspam]).start()
		        elif text_ev_ev_lw.startswith(f'{prefix_true} -лспам'): 
		            commands_count += 1  
		            lSpam_Active = False
		            try:
		                vk8.messages.delete(message_ids=event.message_id, delete_for_all=1)
		            except Exception:
		                pass
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} кабинет'): 
		            if Spam_Active == False:
		                status_spam = 'Включен'
		            else:
		                status_spam = 'Выключен'
		            if lSpam_Active == False:
		                lstatus_spam = 'Включен'
		            else:
		                lstatus_spam = 'Выключен'
		            file = open('status_my.txt', 'r')
		            aa = file.read()
		            file.close()
		            file = open('custom_reply.txt', 'r', encoding='utf-8')
		            rrrr = file.read()
		            file.close()
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Сбор Ваших данных...', captcha_handler=captcha_handler)
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Сбор Ваших данных...' + str(random.randrange(1, 25)) + '%', captcha_handler=captcha_handler)
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Сбор Ваших данных...' + str(random.randrange(26, 50)) + '%', captcha_handler=captcha_handler)
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Сбор Ваших данных...' + str(random.randrange(51, 75)) + '%', captcha_handler=captcha_handler)
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Сбор Ваших данных...' + str(random.randrange(76, 99)) + '%', captcha_handler=captcha_handler)
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Сбор Ваших данных... 100%\nДобро пожаловать!', captcha_handler=captcha_handler)
		            if aa == '1':
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='| Paradox LP |\n+Ваш статус: USER\n+Ваш префикс: ' + str(prefix_true) + '\n+ID Чата: ' + str(event.peer_id) + '\n+Всего команд вызвано за сегодня: ' + str(commands_count) + '\n+Статус спама: ' + str(status_spam) + '\n+Статус Л-спама: ' + str(lstatus_spam) + '\n+Выбран шаблон N: ' + str(spam_pem_shab_variant) + '\n+Бот работает ' + str(time_bot) + ' сек.', captcha_handler=captcha_handler)
		            elif aa == '2':
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Приветствуем, PREMIUM USER!', captcha_handler=captcha_handler)
		                time.sleep(2)
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='| Paradox LP |\n+Ваш статус: PREMIUM USER\n+Ваш префикс: ' + str(prefix_true) + '\n+ID Вашей страницы: ' + str(event.user_id) + '\n+ID Чата: ' + str(event.peer_id) + '\n+Всего команд вызвано за сегодня: ' + str(commands_count) + '\n+Статус спама: ' + str(status_spam) + '\n+Статус Л-спама: ' + str(lstatus_spam) + '\n+Выбран шаблон N:' + str(spam_pem_shab_variant) + '\n+Текст для отвечалки: ' + str(rrrr) + '\n+Бот работает ' + str(time_bot) + ' сек.', captcha_handler=captcha_handler)

		        elif text_ev_ev_lw1.startswith(f'{prefix_true} профиль'): 
		            file = open('status_my.txt', 'r')
		            aa = file.read()
		            file.close()
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Сбор Ваших данных...', captcha_handler=captcha_handler)
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Сбор Ваших данных...' + str(random.randrange(1, 25)) + '%', captcha_handler=captcha_handler)
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Сбор Ваших данных...' + str(random.randrange(26, 50)) + '%', captcha_handler=captcha_handler)
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Сбор Ваших данных...' + str(random.randrange(51, 75)) + '%', captcha_handler=captcha_handler)
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Сбор Ваших данных...' + str(random.randrange(76, 99)) + '%', captcha_handler=captcha_handler)
		            if aa == '1':
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Paradox Info\n— Префикс: ' + str(prefix_true) + '\n— Статус: USER\n— Подписка активна до UNLIMITED\n— Состояние капчи: UNLIMITED\n— Состояние пинга: ' + str(time.time() - float(event.timestamp)).replace('-', '') + ' мс.', captcha_handler=captcha_handler)
		            elif aa == '2':
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Paradox Info\n— Префикс: ' + str(prefix_true) + '\n— Статус: PREMIUM USER\n— ID Вашей страницы: ' + str(event.user_id) + '\n— Подписка активна до UNLIMITED\n— Состояние капчи: UNLIMITED\n— Состояние пинга: ' + str(time.time() - float(event.timestamp)).replace('-', '') + ' мс.', captcha_handler=captcha_handler)
 


		        elif text_ev_ev_lw1.startswith(f'{prefix_true} пинг'):  
		            commands_count += 1         
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Обработал за ' + str(time.time() - float(event.timestamp)).replace('-', '') + ' мс.\n- - - - - - - - - - - - - - -', captcha_handler=captcha_handler)
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} 11'):  
		            commands_count += 1         
		            print(vk8.messages.getHistory(count=100, user_id=str(vk8.users.get()[0]['id']), peer_id=event.peer_id)['items'][0]['id'])
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} команды'):   
		            commands_count += 1          
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Команды: https://vk.cc/cnC0FU', captcha_handler=captcha_handler)
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} мой_айди'):        
		            commands_count += 1     
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Ваш ID: ' + str(event.user_id) + '\nВаш тег: ' + str(event.user_id), captcha_handler=captcha_handler)
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} чат_айди'):
		            commands_count += 1 
		            if int(event.peer_id) > 2000000000:
		                peer_uk = int(event.peer_id) - 2000000000          
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='ID Чата (полный): ' + str(event.peer_id) + '\nID Чата (укороченный): ' + str(peer_uk), captcha_handler=captcha_handler)
		            elif int(event.peer_id) < 0:        
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='ID Чата (группы): ' + str(event.peer_id), captcha_handler=captcha_handler)
		            else:
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='ID Чата (пользователя): ' + str(event.peer_id) + '\nТег пользователя: @id' + str(event.peer_id), captcha_handler=captcha_handler)
		        elif text_ev_ev_lw.startswith(f'{prefix_true} +др'): 
		            commands_count += 1           
		            your_string = event.text
		            removal_list = [prefix_true + " +др"]
		            for word in removal_list:
		            	your_string = your_string.replace(word, "")

		            us=event.user_id
		            if your_string == '':
		                message=vk8.messages.getById(message_ids=event.message_id)['items'][0]
		                if 'reply_message' in message:
		                    aidd=message['reply_message']['from_id']
		                    try:
		                        vk8.friends.add(user_id=aidd)
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Добавил в друзья!', captcha_handler=captcha_handler)
		                    except Exception as e:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Не удалось добавить в друзья.', captcha_handler=captcha_handler)
		            else:            
		                try:
		                    removal_list = ["https://vk.com/"]
		                    for word in removal_list:
		                        kk = your_string.replace(word, "")
		                    removal_list = ["@"]
		                    for word in removal_list:
		                        kk2 = kk.replace(word, "")

		                    removal_list = ["vk.com/"]
		                    for word in removal_list:
		                        kk = kk2.replace(word, "")

		                    if your_string.find("@") != -1:
		                        result_t = kk.split('|')[1]
		                        res_str = result_t.replace(']', '', 1)
		                    else:
		                        res_str = kk


		                    aidd = vk8.utils.resolveScreenName(screen_name=res_str)['object_id']

		                    try:
		                        vk8.friends.add(user_id=aidd)
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Добавил в друзья!', captcha_handler=captcha_handler)
		                    except Exception as e:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Не удалось добавить в друзья.', captcha_handler=captcha_handler)
		                    
		                except Exception as e:
		                    print(e)
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователь не найден.', captcha_handler=captcha_handler)
		        elif text_ev_ev_lw.startswith(f'{prefix_true} -др'):   
		            commands_count += 1         
		            your_string = event.text
		            removal_list = [prefix_true + " -др"]
		            for word in removal_list:
		            	your_string = your_string.replace(word, "")

		            us=event.user_id
		            if your_string == '':
		                message=vk8.messages.getById(message_ids=event.message_id)['items'][0]
		                if 'reply_message' in message:
		                    aidd=message['reply_message']['from_id']
		                    try:
		                        vk8.friends.delete(user_id=aidd)
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Удалён из друзей!', captcha_handler=captcha_handler)
		                    except Exception as e:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Не удалось удалить из друзей.', captcha_handler=captcha_handler)
		            else:            
		                try:
		                    removal_list = ["https://vk.com/"]
		                    for word in removal_list:
		                        kk = your_string.replace(word, "")
		                    removal_list = ["@"]
		                    for word in removal_list:
		                        kk2 = kk.replace(word, "")

		                    removal_list = ["vk.com/"]
		                    for word in removal_list:
		                        kk = kk2.replace(word, "")

		                    if your_string.find("@") != -1:
		                        result_t = kk.split('|')[1]
		                        res_str = result_t.replace(']', '', 1)
		                    else:
		                        res_str = kk


		                    aidd = vk8.utils.resolveScreenName(screen_name=res_str)['object_id']

		                    try:
		                        vk8.friends.delete(user_id=aidd)
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Удалён из друзей!', captcha_handler=captcha_handler)
		                    except Exception as e:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Не удалось удалить из друзей.', captcha_handler=captcha_handler)
		                    
		                except Exception as e:
		                    print(e)
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователь не найден.', captcha_handler=captcha_handler)
		        elif text_ev_ev.startswith(f'{prefix_true} игнор'):           
		            your_string = event.text
		            removal_list = [prefix_true + " игнор"]
		            for word in removal_list:
		            	your_string = your_string.replace(word, "")
		            

		            us=event.user_id
		            if your_string == '':
		                message=vk8.messages.getById(message_ids=event.message_id)['items'][0]
		                if 'reply_message' in message:
		                    aidd=message['reply_message']['from_id']
		                    if int(aidd) == int(vk8.users.get()[0]['id']):
		                    	vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Вы пытаетесь замутить себя самого.', captcha_handler=captcha_handler)
		                    	break
		                    else:
		                    	pass
		                    try:
		                        file = open('ignore.txt', 'r')
		                        dost = file.read()
		                        file.close()
		                        if str(dost).find(str(aidd)) != -1:
		                            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователь уже находится в игнор-списке', captcha_handler=captcha_handler)
		                            break
		                        else:
		                            pass
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователь добавлен в игнор-список', captcha_handler=captcha_handler)
		                        file = open('ignore.txt', 'a+')
		                        file.write(str(aidd) + '\n')
		                        file.close()
		                    except Exception:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Что-то пошло не так.', captcha_handler=captcha_handler)
		            else:            
		                try:
		                    removal_list = ["https://vk.com/"]
		                    for word in removal_list:
		                        kk = your_string.replace(word, "")
		                    removal_list = ["@"]
		                    for word in removal_list:
		                        kk2 = kk.replace(word, "")

		                    removal_list = ["vk.com/"]
		                    for word in removal_list:
		                        kk = kk2.replace(word, "")

		                    if your_string.find("@") != -1:
		                        result_t = kk.split('|')[1]
		                        res_str = result_t.replace(']', '', 1)
		                    else:
		                        res_str = kk


		                    aidd = vk8.utils.resolveScreenName(screen_name=res_str)['object_id']
		                    if int(aidd) == int(vk8.users.get()[0]['id']):
		                    	vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Вы пытаетесь замутить себя самого.', captcha_handler=captcha_handler)
		                    	break
		                    else:
		                    	pass
		                    file = open('ignore.txt', 'r')
		                    dost = file.read()
		                    file.close()
		                    if str(dost).find(str(aidd)) != -1:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователь уже находится в игнор-списке', captcha_handler=captcha_handler)
		                        break
		                    else:
		                        pass
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователь добавлен в игнор-список', captcha_handler=captcha_handler)
		                    file = open('ignore.txt', 'a+')
		                    file.write(str(aidd) + '\n')
		                    file.close()
		                except Exception as e:
		                    print(e)
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователь не найден.', captcha_handler=captcha_handler)      
		        elif text_ev_ev.startswith(f'{prefix_true} -игнор'):           
		            your_string = event.text
		            removal_list = [prefix_true + " -игнор"]
		            for word in removal_list:
		            	your_string = your_string.replace(word, "")
		            

		            us=event.user_id
		            if your_string == '':
		                message=vk8.messages.getById(message_ids=event.message_id)['items'][0]
		                if 'reply_message' in message:
		                    aidd=message['reply_message']['from_id']
		                    file = open('ignore.txt', 'r')
		                    dost = file.read()
		                    file.close()
		                    if str(dost).find(str(aidd)) != -1:
		                        pass
		                    else:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователя нет в игнор-списке', captcha_handler=captcha_handler)
		                        break
		                    try:
		                        with open("ignore.txt", "r") as f:
		                            lines = f.readlines()
		                        with open("ignore.txt", "w") as f:
		                            for line in lines:
		                                if line.strip("\n") != str(aidd):
		                                    f.write(line)
		                            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Убран из игнор-списка.', captcha_handler=captcha_handler)  
		                    except Exception:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Что-то пошло не так.', captcha_handler=captcha_handler)
		                else:
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пустое значение', captcha_handler=captcha_handler)
		            else:            
		                try:
		                    removal_list = ["https://vk.com/"]
		                    for word in removal_list:
		                        kk = your_string.replace(word, "")
		                    removal_list = ["@"]
		                    for word in removal_list:
		                        kk2 = kk.replace(word, "")

		                    removal_list = ["vk.com/"]
		                    for word in removal_list:
		                        kk = kk2.replace(word, "")

		                    if your_string.find("@") != -1:
		                        result_t = kk.split('|')[1]
		                        res_str = result_t.replace(']', '', 1)
		                    else:
		                        res_str = kk


		                    aidd = vk8.utils.resolveScreenName(screen_name=res_str)['object_id']
		                    file = open('ignore.txt', 'r')
		                    dost = file.read()
		                    file.close()
		                    if str(dost).find(str(aidd)) != -1:
		                        pass
		                    else:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователя нет в игнор-списке', captcha_handler=captcha_handler)
		                        break
		                    with open("ignore.txt", "r") as f:
		                        lines = f.readlines()
		                    with open("ignore.txt", "w") as f:
		                        for line in lines:
		                            if line.strip("\n") != str(aidd):
		                                f.write(line)
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Убран из игнор-списка', captcha_handler=captcha_handler)
		                except Exception:
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователь не найден.', captcha_handler=captcha_handler)
		        elif text_ev_ev.startswith(f'{prefix_true} +блок пуш'):  
		            if ignote_push_status == True:
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Уже запущено.', captcha_handler=captcha_handler)
		                break
		            else:
		                pass
		            ignote_push_status = True
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='+Блокировка сообщений с общим упоминанием включена', captcha_handler=captcha_handler)
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} -блок пуш'):  
		            if ignote_push_status == True:
		                pass
		            else:
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Не был запущен.', captcha_handler=captcha_handler)
		                break
		            ignote_push_status = False
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='-Блокировка сообщений с общим упоминанием выключена', captcha_handler=captcha_handler)
		        elif text_ev_ev.startswith(f'{prefix_true} дов'):           
		            your_string = event.text
		            removal_list = [prefix_true + " дов"]
		            for word in removal_list:
		            	your_string = your_string.replace(word, "")
		            

		            us=event.user_id
		            if your_string == '':
		                message=vk8.messages.getById(message_ids=event.message_id)['items'][0]
		                if 'reply_message' in message:
		                    aidd=message['reply_message']['from_id']
		                    try:
		                        file = open('dovi.txt', 'r')
		                        dost = file.read()
		                        file.close()
		                        if str(dost).find(str(aidd)) != -1:
		                            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Уже в доверенных', captcha_handler=captcha_handler)
		                            break
		                        else:
		                            pass
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Добавлен в доверенные', captcha_handler=captcha_handler)
		                        file = open('dovi.txt', 'a+')
		                        file.write(str(aidd) + '\n')
		                        file.close()
		                    except Exception:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Что-то пошло не так.', captcha_handler=captcha_handler)
		            else:            
		                try:
		                    removal_list = ["https://vk.com/"]
		                    for word in removal_list:
		                        kk = your_string.replace(word, "")
		                    removal_list = ["@"]
		                    for word in removal_list:
		                        kk2 = kk.replace(word, "")

		                    removal_list = ["vk.com/"]
		                    for word in removal_list:
		                        kk = kk2.replace(word, "")

		                    if your_string.find("@") != -1:
		                        result_t = kk.split('|')[1]
		                        res_str = result_t.replace(']', '', 1)
		                    else:
		                        res_str = kk


		                    aidd = vk8.utils.resolveScreenName(screen_name=res_str)['object_id']
		                    file = open('dovi.txt', 'r')
		                    dost = file.read()
		                    file.close()
		                    if str(dost).find(str(aidd)) != -1:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Уже в доверенных', captcha_handler=captcha_handler)
		                        break
		                    else:
		                        pass
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Добавлен в доверенные', captcha_handler=captcha_handler)
		                    file = open('dovi.txt', 'a+')
		                    file.write(str(aidd) + '\n')
		                    file.close()
		                except Exception as e:
		                    print(e)
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователь не найден.', captcha_handler=captcha_handler)  
		        elif text_ev_ev.startswith(f'{prefix_true} -дов'):           
		            your_string = event.text
		            removal_list = [prefix_true + " -дов"]
		            for word in removal_list:
		            	your_string = your_string.replace(word, "")
		            

		            us=event.user_id
		            if your_string == '':
		                message=vk8.messages.getById(message_ids=event.message_id)['items'][0]
		                if 'reply_message' in message:
		                    aidd=message['reply_message']['from_id']
		                    file = open('dovi.txt', 'r')
		                    dost = file.read()
		                    file.close()
		                    if str(dost).find(str(aidd)) != -1:
		                        pass
		                    else:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Не был в доверенных.', captcha_handler=captcha_handler)
		                        break
		                    try:
		                        with open("dovi.txt", "r") as f:
		                            lines = f.readlines()
		                        with open("dovi.txt", "w") as f:
		                            for line in lines:
		                                if line.strip("\n") != str(aidd):
		                                    f.write(line)
		                            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Убран из доверенных', captcha_handler=captcha_handler)  
		                    except Exception:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Что-то пошло не так.', captcha_handler=captcha_handler)
		                else:
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пустое значение', captcha_handler=captcha_handler)
		            else:            
		                try:
		                    removal_list = ["https://vk.com/"]
		                    for word in removal_list:
		                        kk = your_string.replace(word, "")
		                    removal_list = ["@"]
		                    for word in removal_list:
		                        kk2 = kk.replace(word, "")

		                    removal_list = ["vk.com/"]
		                    for word in removal_list:
		                        kk = kk2.replace(word, "")

		                    if your_string.find("@") != -1:
		                        result_t = kk.split('|')[1]
		                        res_str = result_t.replace(']', '', 1)
		                    else:
		                        res_str = kk


		                    aidd = vk8.utils.resolveScreenName(screen_name=res_str)['object_id']
		                    file = open('dovi.txt', 'r')
		                    dost = file.read()
		                    file.close()
		                    if str(dost).find(str(aidd)) != -1:
		                        pass
		                    else:
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Не был в доверенных', captcha_handler=captcha_handler)
		                        break
		                    with open("dovi.txt", "r") as f:
		                        lines = f.readlines()
		                    with open("dovi.txt", "w") as f:
		                        for line in lines:
		                            if line.strip("\n") != str(aidd):
		                                f.write(line)
		                        vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Убран из доверенных', captcha_handler=captcha_handler)  
		                except Exception:
		                    vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Пользователь не найден.', captcha_handler=captcha_handler)
		        elif text_ev_ev.startswith(f'{prefix_true} +бспам'):  
		            spam_id_text_bottle = event.peer_id
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='.', captcha_handler=captcha_handler) 
		            try:
		                vk8.messages.delete(message_ids=event.message_id, delete_for_all=1)
		            except Exception:
		                pass
		        elif text_ev_ev.startswith(f'{prefix_true} -бспам'):
		            spam_id_text_bottle = ''  
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='.', captcha_handler=captcha_handler) 
		            try:
		                vk8.messages.delete(message_ids=event.message_id, delete_for_all=1)
		            except Exception:
		                pass
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} олег'):  
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='чё?', captcha_handler=captcha_handler) 
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} парадокс'):  
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='слушаю тебя', captcha_handler=captcha_handler) 
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} женя'):  
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='ну', captcha_handler=captcha_handler) 
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} делакруа'):  
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='ась', captcha_handler=captcha_handler) 
		        elif text_ev_ev_lw1.startswith(f'я террорист'):  
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='В Вашем сообщении было недопустимое содержание. Мы отредактировали его для Вашей безопасности, будьте аккуратны!\n\nParadox LP | Security', captcha_handler=captcha_handler) 
		        elif text_ev_ev_lw1.startswith(f'я терорист'):  
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='В Вашем сообщении было недопустимое содержание. Мы отредактировали его для Вашей безопасности, будьте аккуратны!\n\nParadox LP | Security', captcha_handler=captcha_handler) 
		        elif text_ev_ev_lw1.startswith(f'я расстреляю школу'):  
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='В Вашем сообщении было недопустимое содержание. Мы отредактировали его для Вашей безопасности, будьте аккуратны!\n\nParadox LP | Security', captcha_handler=captcha_handler) 
		        elif text_ev_ev_lw1.startswith(f'я убью человека'):  
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='В Вашем сообщении было недопустимое содержание. Мы отредактировали его для Вашей безопасности, будьте аккуратны!\n\nParadox LP | Security', captcha_handler=captcha_handler) 
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} +шаб '): 
		            try:
		                ll = text_ev_ev_lw1.split(prefix_true + ' +шаб ')[1]
		                d = int(ll)
		                if d == 1:
		                	spam_pem_shab_variant = 1
		                elif d == 2:
		                	spam_pem_shab_variant = 2
		                elif d == 3:
		                	spam_pem_shab_variant = 3
		                elif d == 4:
		                	spam_pem_shab_variant = 4
		                else:
		                	vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message="Неверный выбор шаблона, он будет изменён на страндартный!", captcha_handler=captcha_handler)
		                	spam_pem_shab_variant = 1
		                	break

		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message="Вы успешно изменили шаблон на " + str(d), captcha_handler=captcha_handler)
		            except Exception as e:
		                print(e)
		                vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Не число, шаблон был изменён на страндартный!', captcha_handler=captcha_handler)
		                spam_pem_shab_variant = 1
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} +онлайн'): 
		        	if online_st == 1:
		        		vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Вечный онлайн уже был установлен!', captcha_handler=captcha_handler)
		        	else:
		        		online_st = 1
		        		vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Вечный онлайн установлен!', captcha_handler=captcha_handler)
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} -онлайн'): 
		        	if online_st == 1:
		        		vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Вечный онлайн убран!', captcha_handler=captcha_handler)
		        		online_st = 0
		        	else:
		        		vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Вечный онлайн не был установлен!', captcha_handler=captcha_handler)
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} автоф'): 
		        	if online_st == 1:
		        		jj_o = '✅'
		        	else:
		        		jj_o = '⛔'
		        	if st_st_status_avtof == 1:
		        		st_avtof = '✅'
		        	else:
		        		st_avtof = '⛔'
		        	if st_nap == 1:
		        		st_avtof_st_nap = '✅'
		        	else:
		        		st_avtof_st_nap = '⛔'
		        	if st_nap_ook == 1:
		        		st_avtof_ook = '✅'
		        	else:
		        		st_avtof_ook = '⛔'
		        	vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='| | Автоматические функции:\n>Вечный онлайн: ' + str(jj_o) + '\n>Автоматический статус: ' + str(st_avtof) + '\n>Автоматический ответ в беседах: ' + str(st_avtof_st_nap) + '\n>Автоматический ответ в беседах с генерацией: ' + str(st_avtof_ook) + '\n>>>>', captcha_handler=captcha_handler)
		        elif text_ev_ev.startswith(f'{prefix_true} +австатус'):

		        	if status_auto_aa == True:
		        		pass
		        	elif status_auto_aa == False:
		        		vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Уже запущен.', captcha_handler=captcha_handler)
		        		break
		        	status_auto_aa = False
		        	st_st_status_avtof = 1
		        	Thread(target=chist).start()
		        	Thread(target=status_auto).start()
		        	vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Статус запущен.', captcha_handler=captcha_handler)
		        elif text_ev_ev.startswith(f'{prefix_true} -австатус'):

		        	if status_auto_aa == True:
		        		vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Не запущен.', captcha_handler=captcha_handler)
		        		break
		        	elif status_auto_aa == False:
		        		pass
		        	status_auto_aa = True
		        	st_st_status_avtof= 0
		        	vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Статус выключен.', captcha_handler=captcha_handler)
		        	vk8.status.set(text='.', captcha_handler=captcha_handler)
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} афк'):          
		            your_string = event.text
		            peer = event.peer_id
		            file = open('nap_st.txt', 'r')
		            st_np = file.read()
		            file.close()
		            if st_np == '1':
		            	vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Режим АФК уже запущен.', captcha_handler=captcha_handler)
		            	break
		            else:
		            	pass
		            us=event.user_id
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='АФК запущен.', captcha_handler=captcha_handler)
		            napoleon = False
		            file = open('nap_st.txt', 'w+')
		            file.write('1')
		            file.close()
		            st_nap = 1
		            Thread(target=nap).start()
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} -афк'):
		            file = open('nap_st.txt', 'r')
		            st_np = file.read()
		            file.close()
		            if st_np == '1':
		            	pass
		            else:
		            	vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Режим АФК не был включен.', captcha_handler=captcha_handler)    
		            	break       
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='АФК выключен.', captcha_handler=captcha_handler)
		            file = open('nap_st.txt', 'w+')
		            file.write('0')
		            file.close()
		            napoleon = True
		            st_nap = 0
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} ген_афк'):          
		            your_string = event.text
		            peer = event.peer_id
		            file = open('nap_st_ook.txt', 'r')
		            st_np = file.read()
		            file.close()
		            if st_np == '1':
		            	vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Режим АФК-Генерации в беседах уже запущен.', captcha_handler=captcha_handler)
		            	break
		            else:
		            	pass
		            us=event.user_id
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='АФК-Генерация в беседах запущена.', captcha_handler=captcha_handler)
		            ook_tr = False
		            file = open('nap_st_ook.txt', 'w+')
		            file.write('1')
		            file.close()
		            st_nap_ook = 1
		            Thread(target=ook).start()
		        elif text_ev_ev_lw1.startswith(f'{prefix_true} -ген_афк'):
		            file = open('nap_st_ook.txt', 'r')
		            st_np = file.read()
		            file.close()
		            if st_np == '1':
		            	pass
		            else:
		            	vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='Режим генерации в АФК не был включен.', captcha_handler=captcha_handler)    
		            	break       
		            vk8.messages.edit(message_id=event.message_id, peer_id=event.peer_id, message='АФК-Генерация выключена.', captcha_handler=captcha_handler)
		            file = open('nap_st_ook.txt', 'w+')
		            file.write('0')
		            file.close()
		            ook_tr = True
		            st_nap_ook = 0


		            
	except Exception as e:
		print(e)
		pass
